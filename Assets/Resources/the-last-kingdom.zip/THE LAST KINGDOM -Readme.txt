This font is partial.
Terms of use:
Free for personal use only.
For commercial purpose and use of the complete version, please use the donate button and pay via PayPal $13 USD. Send me an email to rangelcastro@hotmail.com, and I will send you 2 files: THE LAST KINGDOM.ttf and THE LAST KINGDOM.otf.
The complete version include:
- Three types of ornaments by using alternates for all gliphs: A+A- ... Z+Z- with Open Type Features or PUA.
- Dingbats by using symbols ^ ~ <>  [] and {}.

